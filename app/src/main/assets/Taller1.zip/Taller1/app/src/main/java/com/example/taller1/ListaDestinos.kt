package com.example.taller1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import org.json.JSONArray

class ListaDestinos : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lista_destinos)

        val listaDestinos = findViewById<ListView>(R.id.listadestinos)
        val destinosString = intent.getStringExtra("destinosFiltrados")
        val destinos = JSONArray(destinosString)

        val nombresDestinos = mutableListOf<String>()
        for (i in 0 until destinos.length()) {
            val destino = destinos.getJSONObject(i)
            nombresDestinos.add(destino.getString("nombre"))
        }

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, nombresDestinos)
        listaDestinos.adapter = adapter

        listaDestinos.setOnItemClickListener { parent, view, position, id ->
            val destinoSeleccionado = destinos.getJSONObject(position)
            val intent = Intent(this, DetalleDestino::class.java).apply {
                putExtra("detalleDestino", destinoSeleccionado.toString())
            }
            startActivity(intent)
        }
    }
}