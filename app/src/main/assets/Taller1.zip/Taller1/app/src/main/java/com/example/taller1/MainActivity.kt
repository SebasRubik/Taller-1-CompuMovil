package com.example.taller1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.nio.charset.Charset

class MainActivity : AppCompatActivity() {

    companion object {
        val favoritos = mutableListOf<String>()
    }

    private var destinosJson = JSONArray()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btn1 = findViewById<Button>(R.id.bedestinos)
        val btn2 = findViewById<Button>(R.id.bfavoritos)
        val btn3 = findViewById<Button>(R.id.brecomendaciones)

        val spinner = findViewById<Spinner>(R.id.scategorias)

        val intent = Intent(applicationContext, ListaDestinos::class.java)
        val intent2 = Intent(applicationContext, Favoritos::class.java)
        val intent3 = Intent(applicationContext, Recomendaciones::class.java)

        cargarJson()

        btn1.setOnClickListener {
            val categoriaSeleccionada = spinner.selectedItem.toString()
            val destinosFiltrados = filtrarDestinosPorCategoria(categoriaSeleccionada)
            intent.putExtra("destinosFiltrados", destinosFiltrados.toString())
            startActivity(intent)
        }

        btn2.setOnClickListener {
            startActivity(intent2)
        }

        btn3.setOnClickListener {
            startActivity(intent3)
        }

    }

    private fun cargarJson() {
        val inputStream = assets.open("destinos.json")
        val size = inputStream.available()
        val buffer = ByteArray(size)
        inputStream.read(buffer)
        inputStream.close()
        val json = String(buffer, Charset.defaultCharset())
        val jsonObject = JSONObject(json)
        destinosJson = jsonObject.getJSONArray("destinos")
    }

    private fun filtrarDestinosPorCategoria(categoria: String): JSONArray {
        val destinosFiltrados = JSONArray()
        for (i in 0 until destinosJson.length()) {
            val destino = destinosJson.getJSONObject(i)
            if (categoria == "Todos" || destino.getString("categoria") == categoria) {
                destinosFiltrados.put(destino)
            }
        }
        return destinosFiltrados
    }
}