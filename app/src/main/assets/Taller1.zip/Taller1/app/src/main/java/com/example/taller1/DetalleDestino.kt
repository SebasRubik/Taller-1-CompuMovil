package com.example.taller1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject

class DetalleDestino : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detalle_destino)

        val nombreDestino = findViewById<TextView>(R.id.nombreDestino)
        val paisDestino = findViewById<TextView>(R.id.paisDestino)
        val categoriaDestino = findViewById<TextView>(R.id.categoriadestino)
        val planDestino = findViewById<TextView>(R.id.plandestino)
        val precioDestino = findViewById<TextView>(R.id.preciodestino)
        val btnFavoritos = findViewById<Button>(R.id.bagfavoritos)


        val destinoString = intent.getStringExtra("detalleDestino")
        val destino = destinoString?.let { JSONObject(it) }

        if (destino != null) {
            nombreDestino.text = destino.getString("nombre")
        }
        if (destino != null) {
            paisDestino.text = destino.getString("pais")
        }
        if (destino != null) {
            categoriaDestino.text = destino.getString("categoria")
        }
        if (destino != null) {
            planDestino.text = destino.getString("plan")
        }
        if (destino != null) {
            precioDestino.text = "USD ${destino.getString("precio")}"
        }

        btnFavoritos.setOnClickListener {
            it.isEnabled = false // Desactivar el botón
            val nombreDestino = destino?.getString("nombre")
            if (nombreDestino != null) {
                MainActivity.favoritos.add(nombreDestino)
            }
            Toast.makeText(this, "Añadido a favoritos", Toast.LENGTH_SHORT).show()
        }
    }
}